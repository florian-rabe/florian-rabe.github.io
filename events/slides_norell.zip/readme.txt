slides/   -- pdf version of the slides
code/     -- the Agda code I showed (needs the standard library)
html/     -- browsable version of the code (start with Talk.html)