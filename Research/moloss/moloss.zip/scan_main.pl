#!/usr/local/bin/perl

#BASIC_SCAN by Thomas Schwickert, January 1995
#Modified by Hans Juergen Ohlbach
#Modified by Renate Schmidt, Oct 1999
#Specialiced to certain correspondence problems, WWW interface removed by Florian Rabe, Jun 2006
# Example: ./scan_main.pl "imp(box(and(p,q)),and(p,q))" "p,q"
# returns: (all x0 acc(x0,x0))
# use "no-cleanup" as third argument to keep temporary files for debugging (see end of file)

#specialized input instead of form data 

#This must be the SCAN directory (ending with a slash)
$path = "/afs/cs.cmu.edu/user/florian/implementation_florian/scan/";
#This must be the path to Prolog
$FORM{'prolog'} = "/afs/cs.cmu.edu/user/florian/sunos/prolog/yap/local/bin/yap";

#These fields can be customized.
$FORM{'formula'} = $ARGV[0]; 
$FORM{'predicates'} = $ARGV[1];
$FORM{'translation_program'} = $path . "scan.pl";
$FORM{'library'} = $path . "operators.pl";
$FORM{'program'} = $path . "Scan";
$ausgabe = "/tmp/scan_out";

#This defines the syntax of the input language
$Acc = "explworacc";
$FORM{'operators'} =
	"unary(not,-).\n" .
	"binary(and,&).\n" .
	"binary(or,|).\n" .
	"binary(imp,->).\n" .
	"binary(eqv,<->).\n" .
	"box(box,$Acc).\n" .
	"diamond(dia,$Acc).\n";

#These fields are not important.
$FORM{'truth_condition'} = "all";
$FORM{'assumptions'} = "";
$FORM{'qualifications'} = "";
$FORM{'rewrite'} = "";
$FORM{'max_seconds'}=""; # time check removed
$FORM{'check_redundancy_time'} = "set(check_redundancy_time,1).";
$FORM{'minimize_at_end_time'} = "set(minimize_at_end_time,1).";
#$FORM{'print_kept'} = "clear(print_kept). clear(print_given).";
$FORM{'print_kept'} = "set(print_kept). set(print_given).";
$FORM{'negate_first'}= "";

# $debug = 1;                # for debugging
# $debug = undef;

# Preparations of the variables (reader may want to skip the indented part) 
    # Truth Condition
    $FORM{'truth_condition'} =~ s/'.'//eg;
    
    if($FORM{'truth_condition'} =~ /trc\(/ ){
    	$FORM{'truth_condition'} = "$FORM{'truth_condition'}.";}
    else {
    	$FORM{'truth_condition'} = "truth_condition($FORM{'truth_condition'}).";
    }
    
    
    #Formula
    $FORM{'formula'} =~ s/\'//eg;
    $FORM{'formula'} =~ s/(\n|\r|\f)//eg;
    $FORM{'formula'} =~ s/\.//eg;
    
    
    $FORM{'predicates'} = join('\',\'',split(/\,/,$FORM{'predicates'}));
    $FORM{'formula'} = "scan([\'$FORM{'predicates'}\'],\'$FORM{'formula'}\').";
    
    
    # Rewrite System
    $FORM{'rewrite'} =~ s/\s*\n\s*\b//g;
    $FORM{'rewrite'} =~ s/\.\s+$/\./g;
    
    if($FORM{'rewrite'} =~ /rr\(/ ) {
    	$FORM{'rewrite'} = "$FORM{'rewrite'}.";}
    else {
    	$FORM{'rewrite'} = "rr_system($FORM{'rewrite'})."
     unless $FORM{'rewrite'} eq '';}
    
    
    # Operators
    $FORM{'operators'} =~ s/\s*\n\s*\b//g;
    $FORM{'operators'} =~ s/\.\s+$/\./g;
    
    @OPERATORS = split(/\./, $FORM{'operators'});
    
    foreach $operator (@OPERATORS)
    {
    if($operator =~ /op\(/)
       {($op,$nr,$ass,$opr) = split(/\(|\,|\)/,$operator);
        $operator = "op\($nr,$ass,\'$opr\'\).";}
      elsif ($operator =~ /op(r|s)\(/)
       {($op,$opr,$def) = split(/\(|\,/,$operator,3);
        $def =~ s/\)$//;
        $operator = "$op\(\'$opr\',\'$def\'\).";}
      else 
       {($op,$opr) = split(/\(/,$operator,2);
        ($op2,$prec) = split(/^.*\)/,$opr); 
        $opr =~ s/\),?\d*$//;
        @opr1 = split(/\,/,$opr);
        foreach $argument (@opr1)
         {$argument = "'$argument'" unless $argument =~ /(\(|[A-Z])/;}
        $opr = join(',',@opr1); 
        if ($prec eq "") 
         {$operator = "operator($op($opr)).";} 
         else
        {$operator = "operator($op($opr)$prec).";}}
    }
    
    
    # Assumptions
    $FORM{'assumptions'} =~ s/\s*\n\s*\b//g;
    $FORM{'assumptions'} =~ s/\.\s+$/\./g;
    
    @ASSUMPTIONS = split(/\./, $FORM{'assumptions'});
    
    foreach $assumption (@ASSUMPTIONS)
    {
    	if($assumption =~ /ass\(/ )
              {$assumption =~ s/^ass\(//;
               $assumption =~ s/\)$//;
               $assumption = "ass('$assumption').";}
            else {
    	   $assumption = "assumption($assumption).";
                 }
    }
    
    
    # Qualifications
    $FORM{'qualifications'} =~ s/\s*\n\s*\b//g;
    $FORM{'qualifications'} =~ s/\.\s+$/\./g;
    
    
    @QUALIFICATIONS = split(/\./, $FORM{'qualifications'});
    
    foreach $qualification (@QUALIFICATIONS)
    {
    	if($qualification =~ /qual\(/ )
              {$qualification =~ s/^qual\(//;
               $qualification =~ s/\)$//;
               $qualification = "qual('$qualification').";}
            else {
    	   $qualification = "qualification($qualification).";
                 }
    }
    
    open(SCAN_INPUT,">/tmp/scan_corr.pl");
    print SCAN_INPUT "[\'$FORM{'translation_program'}\'].\n";
    print SCAN_INPUT "[\'$FORM{'library'}\'].\n";
    print SCAN_INPUT "scan_input_file(\'/tmp/scan_corr.in\').\n";
    print SCAN_INPUT "$FORM{'max_seconds'}\n";
    print SCAN_INPUT "$FORM{'minimize_at_end_time'}\n";
    print SCAN_INPUT "$FORM{'check_redundancy_time'}\n";
    print SCAN_INPUT "$FORM{'print_kept'}\n";
    print SCAN_INPUT "$FORM{'negate_first'}\n";
    print SCAN_INPUT "$FORM{'truth_condition'}\n";
    foreach $operator (@OPERATORS)
    {print SCAN_INPUT "$operator\n";}
    print SCAN_INPUT "$FORM{'rewrite'}\n";
    foreach $assumption (@ASSUMPTIONS)
    {print SCAN_INPUT "$assumption\n";}
    foreach $qualification (@QUALIFICATIONS)
    {print SCAN_INPUT "$qualification\n";}
    print SCAN_INPUT "$FORM{'formula'}\n";    
    close (SCAN_INPUT);

#Prolog program is now in scan_corr.pl,
#executing it will prepare the scan input file scan_corr.in
print <<`EOC`;
cat /tmp/scan_corr.pl > $ausgabe
EOC

`$FORM{'prolog'} < /tmp/scan_corr.pl >> $ausgabe 2>1`;
`$FORM{'program'} < /tmp/scan_corr.in >> $ausgabe 2>1`;

#Output contains the result on a certain line
open(RES,$ausgabe);
$res = <RES>;
until ($res eq "% result of unskolemization:(negated)\n" | $res eq "")
  {$res = <RES>;}
$res = <RES>;
close(RES);

#Cleanup
if ($ARGV[2] ne "no-cleanup") {
	print <<`EOC`;
	rm /tmp/scan_corr.in
	rm /tmp/scan_corr.pl
	rm $ausgabe
EOC
}

#Output result
if ($res) {
    print $res;
}else{
    print "No result\n";
}











